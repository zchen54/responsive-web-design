function project() {
  console.log("in project");
  var windowWidth = $(window).width();
  var bannerTopHeight = $(".project-top-banner").height() - 60;
  // 监听页面滚动
  $(document).scroll(function() {
    var scrollLength = $(document).scrollTop();
    if (windowWidth < 850) {
      if (scrollLength >= bannerTopHeight) {
        $(".project-tab").addClass("tab-fixed-top");
      } else if (scrollLength < bannerTopHeight) {
        $(".project-tab").removeClass("tab-fixed-top");
      }
    } else {
      if (scrollLength >= bannerTopHeight) {
        $(".header").addClass("fixed-top");
        $(".project-tab").addClass("tab-fixed-top-pc");
      } else if (scrollLength < bannerTopHeight) {
        $(".header").removeClass("fixed-top");
        $(".project-tab").removeClass("tab-fixed-top-pc");
      }
    }
  });

  // 公司选择
  $(".content-tab").on("click", ".content-tab-item", function(event) {
    event.preventDefault();
    var companyIndex = $(this).index();
    $(this).addClass("active");
    $(this)
      .siblings(".content-tab-item")
      .removeClass("active");
    $(this)
      .parent()
      .siblings(".content-detail")
      .find(".content-detail-item")
      .hide();
    $(this)
      .parent()
      .siblings(".content-detail")
      .find(".content-detail-item")
      .eq(companyIndex)
      .fadeIn();
  });

  // 分类选择
  $(".rc-proj-select-wrap").on("click", ".btn-cir-green", function(event) {
    event.stopPropagation();
    event.preventDefault();
    var defaultValue = $(this)
      .find(".select-value-text")
      .text();

    $(this)
      .siblings(".rc-proj-select-container")
      .find(".rc-proj-option")
      .each(function() {
        if (
          $(this)
            .text()
            .trim() === defaultValue
        ) {
          $(this).addClass("selected");
          $(this)
            .siblings()
            .removeClass("selected");
        }
      });
    $(this)
      .siblings(".rc-proj-select-container")
      .slideToggle();
  });
  // 选中选项
  $(".rc-proj-select").on("click", ".rc-proj-option", function(event) {
    event.stopPropagation();
    event.preventDefault();
    var selectedValue = $(this).attr("data-value");
    $(this)
      .parent()
      .parent()
      .siblings(".btn-cir-green")
      .find(".select-value-text")
      .text(selectedValue);
    $(this)
      .parent()
      .parent()
      .hide();
  });
  // 关闭分类选择
  $(document).click(function() {
    $(".rc-proj-select-container").hide();
  });
  $(".rc-proj-select-container").click(function(event) {
    event.stopPropagation();
  });

  // 产品选择
  $(".fx-project-wrap").on("mouseenter", ".sq-item", function(event) {
    event.stopPropagation();
    event.preventDefault();
    var productIndex = $(this).index();
    $(this).addClass("active");
    $(this)
      .siblings(".sq-item")
      .removeClass("active");
    $(this)
      .parent()
      .siblings(".fx-project-detail-pos")
      .find(".fx-project-detail-window")
      .addClass("active")
      .fadeIn();
    $(this)
      .parent()
      .siblings(".fx-project-detail-pos")
      .find(".proj-win-detail-item")
      .hide();
    $(this)
      .parent()
      .siblings(".fx-project-detail-pos")
      .find(".proj-win-detail-item")
      .eq(productIndex)
      .fadeIn();
  });

  // 关闭产品弹窗
  $(document).click(function() {
    $(".fx-project-detail-window").fadeOut();
    $(".fx-project-wrap .sq-item").removeClass("active");
    $(".fx-project-detail-window").removeClass("active");
  });
  $(".fx-project-detail-window").click(function(event) {
    event.stopPropagation();
  });
}
